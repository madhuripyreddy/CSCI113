// ConsoleApplication29.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;
//One bit alu is part of the 16 bit alu. We use the opcodes for addition and subtraction: 0 and 1.
void onebitalu(int x, int y, int cin, int op, int &cout, int &sum) {
	if (op == 1 && y == 1) {
		y = 0;
	} else if (op == 1 && y == 0) {
		y = 1;
	}
	int temp;
	sum = x ^ y ^ cin; 
	temp = cin & (x ^ y);
	cout = ((x & y) | temp);
	return;
}
//onebit15 checks the offset 
void onebit15(int x, int y, int cin, int op, int &cout, int &sum, int &offset) {
	if (op == 1 && y == 1) {
		y = 0;
	} else if (op == 1 && y == 0) {
		y = 1;
	}
	int temp;
	sum = (x ^ y) ^ cin;
	temp = cin & (x ^ y);
	cout = (x & y) | temp;
	offset = cin ^ cout;
	return;
}
//Sixteenbitalu includes the 1 bit alu and the onebit15. Its purpose is to check for overflow error and perform operations. 
void sixteenbitalu(int x[], int y[], int op, int &off, int r[]) {
	int temp = op;
	onebitalu(x[15], y[15], op, op, temp, r[15]); 
	for (int i = 14; i > 0; i--) {
		onebitalu(x[i], y[i], temp, op, temp, r[i]);
	}
	int temp2;
	onebit15(x[0], y[0], temp, op, temp2, r[0], off);
}
//rshift is the function in which it will shift the values placed in the registers AC, MQ, and MQ1 to the right. 
void rshift(int ac[], int mq[], int &mq1) {
	mq1 = mq[15];
	int tempac[16];
	int tempmq[16];
	for (int i = 0; i < 16; i++){
		tempmq[i] = mq[i];
		tempac[i] = ac[i];
	}
	for (int i = 0; i < 15; i++) {
		mq[i + 1] = tempmq[i];
	}
	mq[0] = ac[15];
	for (int i = 0; i < 15; i++) {
		ac[i + 1] = tempac[i];
	}
	return;
}
//Display function displays registers and its values using the parameters counter, md, mq, ac, and mqo
void display(int counter[], int md[], int mq[], int ac[], int mqo) {
	for (int i = 12; i < 16; i++)
	{
		cout << counter[i] << "\t";
	}
	for (int i = 0; i < 16; i++)
	{
		cout << md[i] << "\t";
	}
	for (int i = 0; i < 16; i++)
	{
		cout << ac[i] << "\t";
	}
	for (int i = 0; i < 16; i++)
	{
		cout << mq[i] << "\t";
	}
	cout << mqo << endl;
	return;
}
//Booth's algorithm ses the 16-bit ALU as a subcomponent. It has the following subcomponents: Registers MD, AC, MQ (16bits each),and the cycle counter (initialized to 16)
void boothsalgorithm(int md[], int mq[], int ac[]) {
	
	int counter[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 }; //counter set in an array of 16 bits
	int decr[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 }; //decrement set in a array of 16 bits
	int mq1 = 0; 
	int t;

	display(counter, md, mq, ac, mq1); //Displaying Registers MD, AC, MQ (16bits each),and the cycle counter (initialized to 16)
	
	while ((counter[12] != 0) || (counter[13] != 0) || (counter[14] != 0) || (counter[15] != 0)) {
		//while loop th
		if (mq[15] == 0 && mq1 == 1) {
			sixteenbitalu(ac, md, 0, t, ac);
		}
		else if (mq[15] == 1 && mq1 == 0) {
			sixteenbitalu(ac, md, 1, t, ac);
		}
		
		display(counter, md, mq, ac, mq1);
		rshift(ac, mq, mq1);
		
		display(counter, md, mq, ac, mq1);
		sixteenbitalu(counter, decr, 1, t, counter);
	}

	if (mq[15] == 0 && mq1 == 1) {
		sixteenbitalu(ac, md, 0, t, ac);
	}
	else if (mq[15] == 1 && mq1 == 0) {
		sixteenbitalu(ac, md, 1, t, ac);
	}
	display(counter, md, mq, ac, mq1);
	rshift(ac, mq, mq1);
	display(counter, md, mq, ac, mq1);
	cout << endl;
	cout << "result: ";
	for (int i = 0; i < 16; i++) {
		cout << ac[i];
	}
	for (int i = 0; i < 16; i++) {
		cout << mq[i];
	}
	return;
}

//In the driver code, this driver acesses two input operands(in 2�s complement binary) and calls Booth's multiplier by passing operands to display final product
int main(int argc, char **arg) {
	int md[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 }; //Register MD with 16 bits
	int mq[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; //Register MQ with 16 bits
	int ac[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; //Register AC with 16 bits
	cout << "Multiplier in 2s binary with 16 bits:"; //Print multiplier
	for (int i = 0; i < 16; i++) { //for loop that iterates through clock cycle of 16
		cin >> md[i]; //Prints output of Register MD
	}
	cout << endl; 
	cout << "Multiplicand in 2s binary with 16 bits:"; //Print multiplicand
	for (int i = 0; i < 16; i++) { //for loop that iterates through clock cyle of 16
		cin >> mq[i]; //Prints output of Register MQ
	}
	cout << endl;
	cout << "Cycle-counter\tMD\tAC\tMQ\tMQ-1" << endl; //Prints out columns of Registers MD, AC, MQ, and MQ-1
	boothsalgorithm(md, mq, ac); //
	return 0;
}