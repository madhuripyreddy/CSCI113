// ConsoleApplication37.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
using namespace std;

void indexFor4Bits(int v) {  //shows the binary computation in 4 bits for index values 0-15 
	if (v == 0) {
		cout << "0000"; //binary number for value 0 in 4 bits
	}
	else if (v == 1) {
		cout << "0001"; //binary number for value 1 in 4 bits 
	}
	else if (v == 2) {
		cout << "0010"; //binary number for value 2 in 4 bits
	}
	else if (v == 3) {
		cout << "0011"; //binary number for value 3 in 4 bits 
	}
	else if (v == 4) {
		cout << "0100"; //binary number for value 4 in 4 bits 
	}
	else if (v == 5) {
		cout << "0101"; //binary number for value 5 in 4 bits 
	}
	else if (v == 6) {
		cout << "0110";  //binary number for value 6 in 4 bits 
	}
	else if (v == 7) {
		cout << "0111";  //binary number for value 7 in 4 bits 
	}
	else if (v == 8) {
		cout << "1000"; //binary number for value 8 in 4 bits
	}
	else if (v == 9) {
		cout << "1001"; //binary number for value 9 in 4 bits
	}
	else if (v == 10) {
		cout << "1010"; //binary number for value 10 in 4 bits
	}
	else if (v == 11) {
		cout << "1011"; //binary number for value 11 in 4 bits
	}
	else if (v == 12) {
		cout << "1100"; //binary number for value 12 in 4 bits
	}
	else if (v == 13) {
		cout << "1101"; //binary number for value 13 in 4 bits
	}
	else if (v == 14) {
		cout << "1110"; //binary number for value 14 in 4 bits
	}
	else if (v == 15) {
		cout << "1111"; //binary number for value 15 in 4 bits
	}
}
void indexFor3Bits(int v) { //shows binary numbers in 3 bits for index values 0-7
	if (v == 0) {
		cout << "000"; //binary number for value 0 in 3 bits
	}
	else if (v == 1) {
		cout << "001"; //binary number for value 1 in 3 bits
	}
	else if (v == 2) {
		cout << "010"; //binary number for value 2 in 3 bits
	}
	else if (v == 3) {
		cout << "011"; //binary number for value 3 in 3 bits
	}
	else if (v == 4) {
		cout << "100"; //binary number for value 4 in 3 bits
	}
	else if (v == 5) {
		cout << "101"; //binary number for value 5 in 3 bits
	}
	else if (v == 6) {
		cout << "110"; //binary number for value 6 in 3 bits
	}
	else if (v == 7) {
		cout << "111"; //binary number for value 7 in 3 bits
	}
}

void printDecimaltoBinary(int v) { //Shows final output in binary numbers from decimal convertion in array 
	int printarray[10], i;

	for (i = 0; v > 0; i++) {
		printarray[i] = v % 2;
		v = v / 2;
	}
	for (i = i - 1; i >= 0; i--) {
		cout << printarray[i];
	}
}

void DataValueArraythatprints32Bits(int v) { //prints 32 bits in array 
	int printarray[10], i, j;
	int size = 0;

	for (i = 0; v > 0; i++) { // decimal convertion from binary 
		printarray[i] = v % 2;
		v = v / 2;
	}
	int k = i; // after outputing the amount in leading zeros, use final function to print binary value
	for (i = i - 1; i >= 0; i--) {
		size = size + 1;
	}

	for (j = 0; i < (32 - size - 1); ++i) { // Because we have 32 bits, we subtract size to get numerous amounts of zeroes. Since we started size off as 0, we have subtract by 1.
		cout << "0";
	}

	for (k = k - 1; k >= 0; k--) { // this function outputs the given value in terms of binary in 32 bits after the 0s from previous function to give true 32 bit data size
		cout << printarray[k];
	}
}

void tagValuesfor2Bits(int v) { // function is used when printing out tag values in 2 bits

	if (v == 0) {
		cout << "00"; //binary number for tag value 0 in 2 bits
	}
	else if (v == 1) {
		cout << "01"; //binary number for tag value 1 in 2 bits
	}
	else if (v == 2) {
		cout << "10"; //binary number for tag value 2 in 2 bits
	}
	else if (v == 3) {
		cout << "11"; //binary number for tag value 3 in 2 bits
	}
}
void tagValuesfor3Bits(int v) { //function is used when printing out tag values in 3 bits
	if (v == 0) {
		cout << "000"; //binary number for tag value 0 in 3 bits
	}
	else if (v == 1) {
		cout << "001"; //binary number for tag value 1 in 3 bits
	}
	else if (v == 2) {
		cout << "010"; //binary number for tag value 2 in 3 bits
	}
	else if (v == 3) {
		cout << "011"; //binary number for tag value 3 in 3 bits
	}
	else if (v == 4) {
		cout << "100"; //binary number for tag value 4 in 3 bits
	}
	else if (v == 5) {
		cout << "101"; //binary number for tag value 5 in 3 bits
	}
	else if (v == 6) {
		cout << "110"; //binary number for tag value 6 in 3 bits
	}
	else if (v == 7) {
		cout << "111"; //binary number for tag value 7 in 3 bits
	}

}

void Direct_map_cache(int arraymemory[16]) {
	int vinarraymemory[16]; //Array holds data that includes new values incremented by 5
	for (int i = 0; i < 16; i++) {
		vinarraymemory[i] = arraymemory[i] + 5;
	} //New values are filled in their memory address in new array

	const int row = 16;
	const int column = 3;
	int array1[row][column]; // Use array1 for direct mapping cache

	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			array1[i][j] = 0;
		}
	} // i is row and j is column

	for (int i = 0; i < 16; i++) {
		int TEMP = (arraymemory[i]) % 16; // get the index value to look at

		if (array1[TEMP][0] == 0) {
			array1[TEMP][0] = 1; // Sets value
		}

		array1[TEMP][1] = arraymemory[i] / 16;     // sets tag 
		array1[TEMP][2] = vinarraymemory[i]; // sets data value #
	}

	// Output for Direct Mapped Cache
	cout << " Direct Mapped Cache:" << endl;
	cout << "  set# \t v \t tag \t data" << endl;

	for (int i = 0; i < row; i++) {
		cout << endl;
		cout << "  Set ";
		indexFor4Bits(i);
		cout << ": ";
		cout << "        ";
		for (int j = 0; j < column; j++) {
			if (j == 0) {
				if ((array1[i][j]) == 0) {
					cout << "0";
				}
				else {
					printDecimaltoBinary(array1[i][j]);
				}
				cout << "              ";
			}
			else if (j == 1) {
				tagValuesfor2Bits(array1[i][j]);
				cout << "             ";
			}
			else if (j == 2) {
				DataValueArraythatprints32Bits(array1[i][j]);
			}
		}
	}


}
void two_Way_Associative(int arraymemory[16]) {
	int vinsidearraymemory[16];
	for (int i = 0; i < 16; i++) {
		vinsidearraymemory[i] = arraymemory[i] + 5;
	} // fills the new array with the values that are inside the respective memory addresses

	const int row = 16;
	const int column = 4; // include another column for LRU 
	int array1[row][column]; // Use this array used for direct mapping cache

	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			array1[i][j] = 0;
		}
	} // i is row and j is column

	for (int i = 0; i < row / 2; i++) {
		int TEMP = (arraymemory[i * 2]) % 8; // check memory array opn right of ==

		if (((array1[TEMP * 2][2]) == vinsidearraymemory[i * 2]) || ((array1[TEMP * 2 + 1][2]) == vinsidearraymemory[i * 2])) {
			goto CASE1; // jumps to the second memory address accessed by this iteration 
		}
		else if ((array1[TEMP * 2][0]) == 0 && (array1[TEMP * 2 + 1][0]) == 0) { // if none are filled
			array1[TEMP * 2][0] = 1; // Array 1 sets value bit
			array1[TEMP * 2][1] = arraymemory[i * 2] / 8;
			array1[TEMP * 2][2] = vinsidearraymemory[i * 2];

			array1[TEMP * 2][3] = 1; // 1 = just put in
			array1[TEMP * 2 + 1][3] = 0;
		}
		else if ((array1[TEMP * 2][0]) == 1 && (array1[TEMP * 2 + 1][0]) == 0) { // if only 1 is filled
			array1[TEMP * 2 + 1][0] = 1; // sets value bit for second spot
			array1[TEMP * 2 + 1][1] = arraymemory[i * 2] / 8;
			array1[TEMP * 2 + 1][2] = vinsidearraymemory[i * 2];

			array1[TEMP * 2][3] = 0;
			array1[TEMP * 2 + 1][3] = 1; // sets the 4th column, the LRU to show that the second spot is most recent out of the two, hence the 1 in that spot
		}
		else if ((array1[TEMP * 2][0]) == 1 && (array1[TEMP * 2 + 1][0]) == 1) { // if both are filled
			if ((array1[TEMP * 2][3]) == 0 && (array1[TEMP * 2 + 1][3]) == 1) {
				array1[TEMP * 2][1] = arraymemory[i * 2] / 8;
				array1[TEMP * 2][2] = vinsidearraymemory[i * 2];

				array1[TEMP * 2][3] = 1;
				array1[TEMP * 2 + 1][3] = 0;
			}
			else if ((array1[TEMP * 2][3]) == 1 && (array1[TEMP * 2 + 1][3]) == 0) {
				array1[TEMP * 2 + 1][1] = arraymemory[i * 2] / 8;
				array1[TEMP * 2 + 1][2] = vinsidearraymemory[i * 2];

				array1[TEMP * 2][3] = 0;
				array1[TEMP * 2 + 1][3] = 1;
			}
		}

		// second half
	CASE1: int TEMP2 = (arraymemory[i * 2 + 1]) % 8; // 1, 3, 5, 7, 9, 11, 13, 15 ( you will get either 0-7)

		if (((array1[TEMP2 * 2][2]) == vinsidearraymemory[i * 2 + 1]) || ((array1[TEMP2 * 2 + 1][2]) == vinsidearraymemory[i * 2 + 1])) {
			continue; // it will jump out of the initial loop
		}
		else if ((array1[TEMP2 * 2][0]) == 0 && (array1[TEMP2 * 2 + 1][0]) == 0) { // if none are filled
			array1[TEMP2 * 2][0] = 1; // sets value bit
			array1[TEMP2 * 2][1] = arraymemory[i * 2 + 1] / 8;
			array1[TEMP2 * 2][2] = vinsidearraymemory[i * 2 + 1];

			array1[TEMP2 * 2][3] = 1; // 1 = just put in
			array1[TEMP2 * 2 + 1][3] = 0;
		}
		else if ((array1[TEMP2 * 2][0]) == 1 && (array1[TEMP2 * 2 + 1][0]) == 0) { // if only 1 is filled
			array1[TEMP2 * 2 + 1][0] = 1; // sets value bit for second spot
			array1[TEMP2 * 2 + 1][1] = arraymemory[i * 2 + 1] / 8;
			array1[TEMP2 * 2 + 1][2] = vinsidearraymemory[i * 2 + 1];

			array1[TEMP2 * 2][3] = 0;
			array1[TEMP2 * 2 + 1][3] = 1; // sets the 4th column, the LRU to show that the second spot is most recent out of the two, hence the 1 in that spot
		}
		else if ((array1[TEMP2 * 2][0]) == 1 && (array1[TEMP2 * 2 + 1][0]) == 1) { // if both are filled
			if ((array1[TEMP2 * 2][3]) == 0 && (array1[TEMP2 * 2 + 1][3]) == 1) {
				array1[TEMP2 * 2][1] = arraymemory[i * 2 + 1] / 8;
				array1[TEMP2 * 2][2] = vinsidearraymemory[i * 2 + 1];

				array1[TEMP2 * 2][3] = 1;
				array1[TEMP2 * 2 + 1][3] = 0;
			}
			else if ((array1[TEMP2 * 2][3]) == 1 && (array1[TEMP2 * 2 + 1][3]) == 0) {
				array1[TEMP2 * 2 + 1][1] = arraymemory[i * 2 + 1] / 8;
				array1[TEMP2 * 2 + 1][2] = vinsidearraymemory[i * 2 + 1];

				array1[TEMP2 * 2][3] = 0;
				array1[TEMP2 * 2 + 1][3] = 1;
			}
		}
	}

	// Output results for 2-way associative cache
	cout << " 2-Way Set Associative Cache:" << endl;
	cout << "       set#     \t      v    \t    tag   \t data " << endl;
	int numblock = 0; // seperate blocks into 2 
	for (int i = 0; i < row / 2; i++) { // 8 sets
		cout << endl;

		cout << "    Set ";
		indexFor3Bits(i);
		cout << " Block" << numblock << ": ";
		cout << "                 ";
		for (int j = 0; j < column - 1; j++) { //Subtract column by 1 in order to avoid printing out the LRU
			if (j == 0) {
				if ((array1[i * 2][j]) == 0) {
					cout << "0";
				}
				else {
					printDecimaltoBinary(array1[i * 2][j]);
				}
				cout << "                    ";
			}
			else if (j == 1) {
				tagValuesfor3Bits(array1[i * 2][j]);
				cout << "             ";
			}
			else if (j == 2) {
				DataValueArraythatprints32Bits(array1[i * 2][j]);
			}
		}

		cout << endl << "    Set ";
		indexFor3Bits(i);
		cout << " Block" << numblock + 1 << ": ";
		cout << "                 ";
		for (int j = 0; j < column - 1; j++) { //Subtract column by 1 in order to avoid printing out LRU
			if (j == 0) {
				if ((array1[i * 2 + 1][j]) == 0) {
					cout << "0";
				}
				else {
					printDecimaltoBinary(array1[i * 2 + 1][j]);
				}
				cout << "                    ";
			}
			else if (j == 1) {
				tagValuesfor3Bits(array1[i * 2 + 1][j]);
				cout << "             ";
			}
			else if (j == 2) {
				DataValueArraythatprints32Bits(array1[i * 2 + 1][j]);
			}
		}
		cout << endl;
	}
}

int main() {
	int memoryblock[16] = { 1,4,8,5,20,17,19,56,9,11,4,43,5,6,9,17 }; //array of 16 numbers 
	Direct_map_cache(memoryblock);

	cout << endl << endl << endl;
	two_Way_Associative(memoryblock);


	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
